import mongoose from "mongoose";
import { env } from "./env.js";

export async function connectDB() {
  if (!env.mongoUri) {
    console.warn(
      "[db] MONGODB_URI is not set — skipping database connection. " +
        "Submissions will still be emailed, but won't be saved."
    );
    return;
  }

  try {
    // Fail fast (5s) rather than hanging for mongoose's default 30s
    // if the URI is wrong or Atlas is unreachable.
    await mongoose.connect(env.mongoUri, { serverSelectionTimeoutMS: 5000 });
    console.log("[db] Connected to MongoDB");
  } catch (err) {
    console.error("[db] MongoDB connection failed:", err.message);
    // Don't crash the server over this — the contact form can still
    // email you even if the database is temporarily unreachable.
  }
}

export default connectDB;
